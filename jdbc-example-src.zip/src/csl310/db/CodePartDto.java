/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csl310.db;

/**
 *
 * @author auser
 */
public class CodePartDto {
    public Integer codeId; // PK
    public Integer postId; // FK
    public String charFP;
    public String code;
    
}
